quarkcoin-hash-python
=====================

Python module with quarkcoin's hashing algorithm used by some other tools
